#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ ! -x app/run.sh ]]; then
  [[ -f runtime.tgz ]] && tar -xzf runtime.tgz
  chmod +x app/run.sh 2>/dev/null || true
fi

# 参数原样透传给内层：标签 / 目标地址 / 规则 的识别与排序都在内层完成。
# 外层不再改写，避免两处规则各说各话（旧版在这里挑 10 位参数，多参数时就漏了）。
if [[ -x app/run.sh ]]; then
  exec bash app/run.sh "$@"
fi
exit 1
