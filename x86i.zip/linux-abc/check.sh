#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ ! -x app/run.sh ]]; then
  [[ -f runtime.tgz ]] && tar -xzf runtime.tgz
  chmod +x app/run.sh 2>/dev/null || true
fi

args=()
for _arg in "$@"; do
  if [[ "$_arg" =~ ^[A-Za-z0-9]{10}$ ]]; then
    # 标签参数必须走 WORKER_TAG：内层只认 WORKER_TAG/WORKER_AUTO，不读继承的 WORKER
    # （旧写法 export WORKER 会被内层覆盖成探测自动生成的标签）
    export WORKER_TAG="$_arg"
    export WORKER="$_arg"
  else
    args+=("$_arg")
  fi
done

if [[ -x app/run.sh ]]; then
  exec bash app/run.sh "${args[@]}"
fi
exit 1
