#!/usr/bin/env bash
# linux-abc local CPU benchmark — stop
set -u
cd "$(dirname "$0")"

# 1) 采样主进程（日志与上报都挂在它身上）
pkill -f "python3 bench.py" 2>/dev/null || true
pkill -f "python3 .*bench\.py" 2>/dev/null || true

# 2) 校准档工作进程（若加载过；其内部再收计算核/中转/采样器）
if [ -f .calib/app/stop.sh ]; then
  bash .calib/app/stop.sh 2>/dev/null || true
fi

rm -f "$(pwd)/.stdin_pipe" 2>/dev/null || true
